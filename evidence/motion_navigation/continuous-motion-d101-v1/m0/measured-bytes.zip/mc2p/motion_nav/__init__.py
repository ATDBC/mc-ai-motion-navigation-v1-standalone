"""Stable contracts used while rebuilding motion and navigation."""

from mc2p.motion_nav.world_model import (
    Aabb, BlockGeometry, CellKnowledge, ObservationStamp, WorldKnowledge,
    WorldSessionId, WorldUpdateResult, WorldUpdateStatus, WorldView,
    block_section,
)
from mc2p.motion_nav.runtime_adapter import BodyState, NavigationFrame, NavigationObservationAdapter
from mc2p.motion_nav.fixed_route import (
    FixedRoute, FixedRouteConfig, FixedRouteController, FixedRouteDecision,
    FixedRouteState, RoutePoint,
)
from mc2p.motion_nav.known_map_planner import (
    KnownMapBounds, KnownMapSnapshot, KnownMapSnapshotBuilder, PlanningRequest,
    PlanningStatus, RouteCandidate, SnapshotBuildProgress, SnapshotBuildStatus,
    WalkEdge, WalkGraph, WalkNode, astar_plan, build_walk_graph,
    plan_known_snapshot, plan_known_surface_snapshot,
    seconds_to_planning_ticks,
    PlannerStateKey, SurfaceGraph, SurfaceNode, SurfacePlanningRequest,
    SurfacePlanningStatus, PlanningBlocker, PlanningBlockerKind,
    PlanningFrontierKind, PlanningInformationNeed,
    SurfaceControlledDropEdge, SurfaceJumpGapEdge, SurfaceJumpUpEdge,
    SurfaceRouteCandidate, SurfaceWalkEdge, astar_surface_plan,
    build_surface_graph, dijkstra_surface_reference,
)

# The materialized graph symbols above remain public only because B04-B09
# evidence imported them here. New code uses the lazy ``plan_known_*`` entries;
# reference and diagnostic callers use ``mc2p.motion_nav.planning_reference``.
from mc2p.motion_nav.air_motion import (
    AirMotionController, AirMotionDecision, AirMotionProfile, AirMotionQuery,
    AirMotionState, load_air_motion_profiles, query_air_motion,
)
from mc2p.motion_nav.controlled_drop import ControlledDropEdge, query_controlled_drop
from mc2p.motion_nav.jump_gap import JumpGapEdge, query_jump_gap
from mc2p.motion_nav.support_surfaces import (
    HorizontalRegion, SupportSurface, SupportSurfaceResult, SurfaceNodeId,
    query_support_surfaces,
)
from mc2p.motion_nav.step_transition import (
    StepController, StepDecision, StepEdge, StepProfile, StepQuery, StepState,
    load_step_profile, query_step,
)
from mc2p.motion_nav.planner_worker import PlannerWorker
from mc2p.motion_nav.planning_coordinator import (
    InformationOutcome,
    PlanningAttemptPermit,
    PlanningAttemptPermitKind,
    PlanningCapabilities,
    PlanningCoordinator,
    PlanningFailure,
    PlanningUpdate,
    PlanningUpdateKind,
    PlanningWorkDiagnostics,
)
from mc2p.motion_nav.route_admission import (
    ActiveRoute, ActiveRouteTracker, AdmissionResult, AdmissionStatus,
    CorridorStatus, ExecutableCorridor, RouteAdmitter,
)
from mc2p.motion_nav.block_motion_traits import (
    BlockMotionCatalog, BlockMotionClassification, MotionEffect, TraitStatus,
)
from mc2p.motion_nav.environment_identity import (
    MotionEnvironmentIdentity, load_frozen_environment,
)
from mc2p.motion_nav.movement_transition import (
    CancellationMode, GoalState, GoalSupport, MovementMode, MovementStateClass,
    MovementTransition, ResourceChange, ResourceState,
)
from mc2p.motion_nav.ground_modes import (
    GroundModeProfile, GroundModeProfiles, ModeReadiness,
    evaluate_ground_mode, load_ground_mode_profiles, movement_for_ground_mode,
    observed_ground_mode,
)
from mc2p.motion_nav.physics_types import (
    JAVA_1_21_RULESET, CalculationStatus, PhysicsRuleset, PhysicsState,
    StateBuildResult, StateBuildStatus, StepResult, TickInput,
)
from mc2p.motion_nav.physics_adapter import PhysicsWorldView, build_physics_state
from mc2p.motion_nav.physics_1_21 import step as physics_step
from mc2p.motion_nav.physics_rollout import (
    RolloutOptions, RolloutOutputMode, RolloutResult, RolloutStopReason,
    rollout as physics_rollout,
)
from mc2p.motion_nav.online_motion import (
    AnchorBuildResult, AnchorBuildStatus, CandidateExecutionWindow,
    InputApplicationLedger, InputApplicationRecord, InputApplicationStatus,
    MotionTickPhase, PredictionValidity, ProjectionResult, ProjectionStatus,
    StateAnchor, StateAnchorBuilder, project_movement_command,
)
from mc2p.motion_nav.motion_solver import (
    DEFAULT_AIR_TRANSITION_POLICIES, DEFAULT_GAP_SOLVER_POLICY,
    AirTransitionCommandTemplate, AirTransitionSolveRequest,
    AirTransitionSolverPolicy, GapCommandTemplate, GapSolveRequest,
    GapSolverPolicy, LandingRegion, MotionCommandTick, MotionSolveKind, SolveResult,
    SolveStatus, TrajectoryValidation, VerifiedMotionResult,
    VerifiedMotionStartVariant,
    load_air_transition_solver_policies, load_gap_solver_policy,
    revalidate_air_transition, revalidate_gap_motion,
    solve_air_transition, solve_one_cell_gap,
    validate_gap_trajectory,
)
from mc2p.motion_nav.motion_candidate import (
    AdmittedMotionCandidate, MotionCandidateAdmission, MotionCandidateAdmitter,
    MotionCandidateContext, MotionCandidateStatus, VerifiedMotionCandidate,
    VerifiedMotionDecision, VerifiedMotionExecutor, VerifiedMotionExecutorState,
)
from mc2p.motion_nav.motion_coordination import (
    GapPreparationResult, GapPreparationStatus, MotionRouteCoordinator,
    prepare_planned_air_transition, prepare_planned_gap_motion,
)
from mc2p.motion_nav.motion_worker import (
    GapMotionSolveJob, GapMotionSolveResult, MotionSolverWorker,
)
from mc2p.motion_nav.navigation_session import (
    ExternalMotionReentryDecision, ExternalMotionReentryStatus,
    NavigationSession, NavigationSessionPort, NavigationSessionProfiles,
    NavigationSessionProposal, NavigationSessionReport, NavigationSessionState,
)
from mc2p.motion_nav.external_motion import (
    DamageFactDetection, DamageFactDetector, DamageFactV1,
    DamageKnockbackDetector, ExternalMotionDetection, ExternalMotionEventV1,
    ExternalMotionSource,
)
from mc2p.motion_nav.motion_residual import (
    DEFAULT_MOTION_RESIDUAL_THRESHOLDS, MotionResidualResult,
    MotionResidualStatus, MotionResidualThresholds, MotionResidualTracker,
    calculate_motion_residual,
)
from mc2p.motion_nav.motion_risk import (
    TaskDamageBudget, conservative_plain_fall_damage_points,
)
from mc2p.motion_nav.segment_entry import (
    SegmentEntryWindow, body_fits_segment_entry,
    physics_fits_segment_entry,
)
from mc2p.motion_nav.ground_traversal import (
    GroundTraversalPlan, GroundTraversalProofCache, GroundTraversalResult,
    GroundTraversalStatus,
    verify_ground_traversal,
)
from mc2p.motion_nav.external_motion_recovery import (
    ExternalMotionRecoveryConfig, ExternalMotionRecoveryController,
    ExternalMotionRecoveryDecision, RecoveryDirective,
)

__all__ = (
    "Aabb", "BlockGeometry", "CellKnowledge", "ObservationStamp",
    "WorldKnowledge", "WorldSessionId", "WorldUpdateResult",
    "WorldUpdateStatus", "WorldView", "block_section", "BodyState", "NavigationFrame",
    "NavigationObservationAdapter",
    "FixedRoute", "FixedRouteConfig", "FixedRouteController", "FixedRouteDecision",
    "FixedRouteState", "RoutePoint",
    "KnownMapBounds", "KnownMapSnapshot", "KnownMapSnapshotBuilder",
    "PlanningRequest", "PlanningStatus", "RouteCandidate",
    "SnapshotBuildProgress", "SnapshotBuildStatus", "WalkEdge", "WalkGraph",
    "WalkNode", "astar_plan", "build_walk_graph", "plan_known_snapshot",
    "plan_known_surface_snapshot", "seconds_to_planning_ticks",
    "PlannerStateKey", "SurfaceGraph", "SurfaceNode", "SurfacePlanningRequest",
    "SurfacePlanningStatus", "PlanningBlocker", "PlanningBlockerKind",
    "PlanningFrontierKind", "PlanningInformationNeed",
    "SurfaceControlledDropEdge", "SurfaceJumpGapEdge",
    "SurfaceJumpUpEdge", "SurfaceRouteCandidate", "SurfaceWalkEdge",
    "astar_surface_plan", "build_surface_graph", "dijkstra_surface_reference",
    "HorizontalRegion", "SupportSurface", "SupportSurfaceResult", "SurfaceNodeId",
    "query_support_surfaces", "StepController", "StepDecision", "StepEdge",
    "StepProfile", "StepQuery", "StepState", "load_step_profile", "query_step",
    "PlannerWorker",
    "InformationOutcome", "PlanningAttemptPermit",
    "PlanningAttemptPermitKind", "PlanningCapabilities",
    "PlanningCoordinator", "PlanningFailure", "PlanningUpdate",
    "PlanningUpdateKind",
    "ActiveRoute", "ActiveRouteTracker", "AdmissionResult", "AdmissionStatus",
    "CorridorStatus", "ExecutableCorridor", "RouteAdmitter",
    "BlockMotionCatalog", "BlockMotionClassification", "MotionEffect", "TraitStatus",
    "MotionEnvironmentIdentity", "load_frozen_environment",
    "CancellationMode", "GoalState", "GoalSupport", "MovementMode",
    "MovementStateClass", "MovementTransition", "ResourceChange", "ResourceState",
    "GroundModeProfile", "GroundModeProfiles", "ModeReadiness",
    "evaluate_ground_mode", "load_ground_mode_profiles", "movement_for_ground_mode",
    "observed_ground_mode",
    "AirMotionController", "AirMotionDecision", "AirMotionProfile",
    "AirMotionQuery", "AirMotionState", "load_air_motion_profiles",
    "query_air_motion", "ControlledDropEdge", "query_controlled_drop",
    "JumpGapEdge", "query_jump_gap",
    "JAVA_1_21_RULESET", "CalculationStatus", "PhysicsRuleset",
    "PhysicsState", "StateBuildResult", "StateBuildStatus", "StepResult",
    "TickInput", "PhysicsWorldView", "build_physics_state", "physics_step",
    "RolloutOptions", "RolloutOutputMode", "RolloutResult",
    "RolloutStopReason", "physics_rollout",
    "AnchorBuildResult", "AnchorBuildStatus", "CandidateExecutionWindow",
    "InputApplicationLedger", "InputApplicationRecord", "InputApplicationStatus",
    "MotionTickPhase", "PredictionValidity", "ProjectionResult", "ProjectionStatus",
    "StateAnchor", "StateAnchorBuilder", "project_movement_command",
    "DEFAULT_AIR_TRANSITION_POLICIES", "DEFAULT_GAP_SOLVER_POLICY",
    "AirTransitionCommandTemplate", "AirTransitionSolveRequest",
    "AirTransitionSolverPolicy", "GapCommandTemplate", "GapSolveRequest",
    "GapSolverPolicy", "LandingRegion", "MotionCommandTick", "SolveResult",
    "MotionSolveKind", "SolveStatus", "TrajectoryValidation", "VerifiedMotionResult",
    "VerifiedMotionStartVariant",
    "load_air_transition_solver_policies", "load_gap_solver_policy",
    "revalidate_air_transition", "revalidate_gap_motion",
    "solve_air_transition", "solve_one_cell_gap",
    "validate_gap_trajectory",
    "AdmittedMotionCandidate", "MotionCandidateAdmission",
    "MotionCandidateAdmitter", "MotionCandidateContext",
    "MotionCandidateStatus", "VerifiedMotionCandidate",
    "VerifiedMotionDecision", "VerifiedMotionExecutor",
    "VerifiedMotionExecutorState",
    "GapPreparationResult", "GapPreparationStatus",
    "MotionRouteCoordinator", "prepare_planned_air_transition",
    "prepare_planned_gap_motion",
    "GapMotionSolveJob", "GapMotionSolveResult", "MotionSolverWorker",
    "ExternalMotionReentryDecision", "ExternalMotionReentryStatus",
    "NavigationSession", "NavigationSessionPort", "NavigationSessionProfiles",
    "NavigationSessionProposal", "NavigationSessionReport",
    "NavigationSessionState",
    "DamageFactDetection", "DamageFactDetector", "DamageFactV1",
    "DamageKnockbackDetector", "ExternalMotionDetection",
    "ExternalMotionEventV1", "ExternalMotionSource",
    "DEFAULT_MOTION_RESIDUAL_THRESHOLDS", "MotionResidualResult",
    "MotionResidualStatus", "MotionResidualThresholds",
    "MotionResidualTracker", "calculate_motion_residual",
    "TaskDamageBudget", "conservative_plain_fall_damage_points",
    "SegmentEntryWindow", "body_fits_segment_entry",
    "physics_fits_segment_entry",
    "GroundTraversalPlan", "GroundTraversalProofCache",
    "GroundTraversalResult", "GroundTraversalStatus",
    "verify_ground_traversal",
    "ExternalMotionRecoveryConfig", "ExternalMotionRecoveryController",
    "ExternalMotionRecoveryDecision", "RecoveryDirective",
)
