"""B10-A online motion anchors, applied-input ledger and command projection."""
from __future__ import annotations

from dataclasses import dataclass, replace
from enum import StrEnum
import math

from mc2p.contracts.action_receipt import (
    ClientBehaviorReceipt, ClientBehaviorReceiptV2, ClientBehaviorReceiptV3,
    ClientInputApplicationV1,
)
from mc2p.contracts.action_v1 import ActionSnapshotV1, LookV1, MovementV1
from mc2p.contracts.common import ContractViolation, require_identifier, require_nonnegative_int
from mc2p.motion_nav.physics_types import PhysicsRuleset, PhysicsState, TickInput
from mc2p.motion_nav.world_model import WorldSessionId


class InputApplicationStatus(StrEnum):
    IN_FLIGHT = "in_flight"
    PARTIALLY_APPLIED = "partially_applied"
    APPLIED = "applied"
    APPLIED_OUTSIDE_WINDOW = "applied_outside_window"
    EXPIRED = "expired"
    REJECTED = "rejected"
    AMBIGUOUS = "ambiguous"
    SUPERSEDED = "superseded"


class InputResponsibilityStatus(StrEnum):
    CLEAR = "clear"
    IN_FLIGHT = "in_flight"
    AMBIGUOUS = "ambiguous"


class InputResponsibilityDisposition(StrEnum):
    """Whether the current body can move past retained input history."""

    CLEAR = "clear"
    IN_FLIGHT = "in_flight"
    AMBIGUOUS_WAITING = "ambiguous_waiting"
    TRANSFERABLE_FROM_CURRENT_ANCHOR = "transferable_from_current_anchor"


@dataclass(frozen=True, slots=True)
class InputResponsibilityAssessment:
    disposition: InputResponsibilityDisposition
    blocking_sequences: tuple[int, ...] = ()
    latest_possible_tick: int | None = None

    def __post_init__(self) -> None:
        if type(self.disposition) is not InputResponsibilityDisposition:
            raise ContractViolation("input responsibility disposition must be typed")
        if self.blocking_sequences != tuple(sorted(set(self.blocking_sequences))):
            raise ContractViolation("input responsibility sequences must be sorted and unique")
        if (self.latest_possible_tick is not None
                and (type(self.latest_possible_tick) is not int
                     or self.latest_possible_tick < 0)):
            raise ContractViolation("input responsibility latest tick must be nonnegative")


def input_responsibility_status(
    ledger: InputApplicationLedger | None,
    anchor: StateAnchor | None = None,
    *, previous_sequence_floor: int = 0,
) -> InputResponsibilityStatus:
    """Old ambiguous input is cleared only by a later verified body anchor."""
    if ledger is None:
        return InputResponsibilityStatus.CLEAR
    ambiguous = False
    for record in ledger.snapshot():
        if record.action.movement == MovementV1() and record.action.look == LookV1():
            continue
        if record.status in {
                InputApplicationStatus.IN_FLIGHT,
                InputApplicationStatus.PARTIALLY_APPLIED,
        }:
            return InputResponsibilityStatus.IN_FLIGHT
        if record.status is InputApplicationStatus.AMBIGUOUS:
            later_applied = any(
                later.session == record.session
                and later.control_sequence > record.control_sequence
                and later.applied_ticks
                and later.applied_ticks[-1] > record.resolved_at_tick
                and anchor is not None
                and later.applied_ticks[-1] <= anchor.movement_tick_id
                for later in ledger.snapshot()
            ) if record.resolved_at_tick is not None else False
            reanchored_old_input = (
                record.control_sequence <= previous_sequence_floor
                and anchor is not None
                and anchor.session == record.session
                and record.resolved_at_tick is not None
                and anchor.movement_tick_id > record.resolved_at_tick
                and later_applied
            )
            if not reanchored_old_input:
                ambiguous = True
    return (InputResponsibilityStatus.AMBIGUOUS if ambiguous
            else InputResponsibilityStatus.CLEAR)


def assess_input_responsibility(
    ledger: InputApplicationLedger | None,
    anchor: StateAnchor | None = None,
    *, previous_sequence_floor: int = 0,
) -> InputResponsibilityAssessment:
    """Assess present ownership without rewriting an ambiguous past input.

    A later body anchor does not prove whether an old command ran.  It can,
    however, prove that every possible application tick is already reflected
    in the current body state.  The body controller must still verify that its
    current state is safe before using the transferable disposition.
    """
    status = input_responsibility_status(
        ledger, anchor, previous_sequence_floor=previous_sequence_floor,
    )
    if status is InputResponsibilityStatus.CLEAR:
        return InputResponsibilityAssessment(
            InputResponsibilityDisposition.CLEAR,
        )
    if status is InputResponsibilityStatus.IN_FLIGHT:
        blocking = tuple(
            record.control_sequence
            for record in (() if ledger is None else ledger.snapshot())
            if record.action.movement != MovementV1()
            or record.action.look != LookV1()
            if record.status in {
                InputApplicationStatus.IN_FLIGHT,
                InputApplicationStatus.PARTIALLY_APPLIED,
            }
        )
        return InputResponsibilityAssessment(
            InputResponsibilityDisposition.IN_FLIGHT,
            blocking,
        )
    ambiguous = tuple(
        record
        for record in (() if ledger is None else ledger.snapshot())
        if (record.action.movement != MovementV1()
            or record.action.look != LookV1())
        and record.status is InputApplicationStatus.AMBIGUOUS
    )
    blocking = tuple(record.control_sequence for record in ambiguous)
    latest = max((max(
        record.requested_last_tick,
        record.latest_allowed_first_tick + record.action.valid_for_ticks - 1,
        record.resolved_at_tick or 0,
    ) for record in ambiguous), default=None)
    transferable = (
        bool(ambiguous)
        and anchor is not None
        and all(record.session == anchor.session for record in ambiguous)
        and latest is not None
        and anchor.movement_tick_id > latest
    )
    return InputResponsibilityAssessment(
        (InputResponsibilityDisposition.TRANSFERABLE_FROM_CURRENT_ANCHOR
         if transferable else
         InputResponsibilityDisposition.AMBIGUOUS_WAITING),
        blocking,
        latest,
    )


_TERMINAL_INPUT_STATES = frozenset({
    InputApplicationStatus.APPLIED,
    InputApplicationStatus.APPLIED_OUTSIDE_WINDOW,
    InputApplicationStatus.EXPIRED,
    InputApplicationStatus.REJECTED,
    InputApplicationStatus.AMBIGUOUS,
    InputApplicationStatus.SUPERSEDED,
})


@dataclass(frozen=True, slots=True)
class InputApplicationRecord:
    session: WorldSessionId
    control_sequence: int
    action: ActionSnapshotV1
    requested_first_tick: int
    requested_last_tick: int
    latest_allowed_first_tick: int
    status: InputApplicationStatus
    applied_ticks: tuple[int, ...] = ()
    samples: tuple[ClientInputApplicationV1, ...] = ()
    resolved_at_tick: int | None = None

    def __post_init__(self) -> None:
        if type(self.session) is not WorldSessionId or type(self.action) is not ActionSnapshotV1:
            raise ContractViolation("input record requires a session and action")
        for name in (
            "control_sequence", "requested_first_tick", "requested_last_tick",
            "latest_allowed_first_tick",
        ):
            require_nonnegative_int(getattr(self, name), name)
        if self.control_sequence != self.action.request_sequence_id:
            raise ContractViolation("input record control identity mismatch")
        if self.requested_last_tick < self.requested_first_tick:
            raise ContractViolation("input application window is reversed")
        if self.latest_allowed_first_tick < self.requested_first_tick:
            raise ContractViolation("input start window is reversed")
        if type(self.status) is not InputApplicationStatus:
            raise ContractViolation("invalid input application status")
        if self.applied_ticks != tuple(sorted(set(self.applied_ticks))):
            raise ContractViolation("applied ticks must be sorted and unique")
        if len(self.applied_ticks) != len(self.samples):
            raise ContractViolation("applied tick and sample records disagree")


class InputApplicationLedger:
    """Bounded application history maintained by the eventual MotorGateway."""

    def __init__(self, *, max_records: int = 64) -> None:
        if type(max_records) is not int or max_records < 1:
            raise ContractViolation("input ledger limit must be positive")
        self._max_records = max_records
        self._records: dict[int, InputApplicationRecord] = {}
        self._observed_samples: dict[int, ClientInputApplicationV1] = {}
        self._max_samples = max_records * 20 + 1
        self._last_input_samples: int | None = None
        self._last_dropped_input_samples: int | None = None
        self._latest_movement_tick_id: int | None = None
        self._baseline_session: WorldSessionId | None = None
        self._baseline_episode_id: str | None = None
        self._baseline_movement_tick_id: int | None = None

    def establish_baseline(
        self,
        session: WorldSessionId,
        episode_id: str,
        *,
        movement_tick_id: int,
    ) -> None:
        """Start ownership after a reset without claiming older client samples."""
        if type(session) is not WorldSessionId:
            raise ContractViolation("input ledger baseline requires a world session")
        require_identifier(episode_id, "input ledger baseline episode")
        require_nonnegative_int(movement_tick_id, "input ledger baseline movement tick")
        baseline = (session, episode_id, movement_tick_id)
        existing = (
            self._baseline_session,
            self._baseline_episode_id,
            self._baseline_movement_tick_id,
        )
        if self._baseline_session is not None:
            if existing != baseline:
                raise ContractViolation("input ledger baseline cannot change")
            return
        if self._records or self._observed_samples:
            raise ContractViolation("input ledger baseline must precede input records")
        self._baseline_session, self._baseline_episode_id, \
            self._baseline_movement_tick_id = baseline
        self._latest_movement_tick_id = movement_tick_id

    @property
    def baseline_movement_tick_id(self) -> int | None:
        return self._baseline_movement_tick_id

    def submit(self, session: WorldSessionId, action: ActionSnapshotV1, *,
               requested_first_tick: int,
               latest_allowed_first_tick: int | None = None) -> InputApplicationRecord:
        if type(session) is not WorldSessionId or type(action) is not ActionSnapshotV1:
            raise ContractViolation("input submission requires a session and action")
        require_nonnegative_int(requested_first_tick, "requested first tick")
        if (self._baseline_session is not None
                and (session != self._baseline_session
                     or action.episode_id != self._baseline_episode_id
                     or requested_first_tick <= self._baseline_movement_tick_id)):
            raise ContractViolation("input submission precedes or crosses its session baseline")
        if latest_allowed_first_tick is None:
            latest_allowed_first_tick = requested_first_tick
        require_nonnegative_int(
            latest_allowed_first_tick, "latest allowed first tick",
        )
        if latest_allowed_first_tick < requested_first_tick:
            raise ContractViolation("input start window is reversed")
        if (latest_allowed_first_tick != requested_first_tick
                and action.valid_for_ticks != 1):
            raise ContractViolation(
                "a widened start window currently supports only one-tick commands"
            )
        sequence = action.request_sequence_id
        if sequence in self._records:
            raise ContractViolation("duplicate control sequence")
        self._make_room()
        record = InputApplicationRecord(
            session, sequence, action, requested_first_tick,
            requested_first_tick + action.valid_for_ticks - 1,
            latest_allowed_first_tick,
            InputApplicationStatus.IN_FLIGHT,
        )
        self._records[sequence] = record
        return record

    @property
    def latest_movement_tick_id(self) -> int | None:
        return self._latest_movement_tick_id

    def record(self, control_sequence: int) -> InputApplicationRecord | None:
        """Return one immutable command record without exposing ledger ownership."""
        require_nonnegative_int(control_sequence, "control sequence")
        return self._records.get(control_sequence)

    def sample(self, movement_tick_id: int) -> ClientInputApplicationV1 | None:
        """Return the exact client input consumed by one movement tick, if retained."""
        require_nonnegative_int(movement_tick_id, "movement tick id")
        return self._observed_samples.get(movement_tick_id)

    def samples_between(
        self, first_tick: int, last_tick: int,
    ) -> tuple[ClientInputApplicationV1, ...]:
        """Return retained samples in a closed tick interval, in tick order.

        Missing ticks stay missing.  The residual calculator must distinguish an
        incomplete input history from a neutral input instead of inventing one.
        """
        require_nonnegative_int(first_tick, "first movement tick")
        require_nonnegative_int(last_tick, "last movement tick")
        if last_tick < first_tick:
            raise ContractViolation("input sample interval is reversed")
        return tuple(
            sample for tick in range(first_tick, last_tick + 1)
            if (sample := self._observed_samples.get(tick)) is not None
        )

    def observe_sample(self, sample: ClientInputApplicationV1) -> InputApplicationRecord | None:
        if type(sample) is not ClientInputApplicationV1:
            raise ContractViolation("input ledger requires a formal input sample")
        if self._baseline_movement_tick_id is not None:
            if sample.movement_tick_id <= self._baseline_movement_tick_id:
                return None
            if (sample.episode_id is not None
                    and sample.episode_id != self._baseline_episode_id):
                return None
        existing = self._observed_samples.get(sample.movement_tick_id)
        if existing is not None:
            if existing != sample:
                raise ContractViolation("conflicting evidence for one movement tick")
            if sample.request_sequence_id is None:
                return None
            return self._records.get(sample.request_sequence_id)
        if (self._latest_movement_tick_id is not None
                and sample.movement_tick_id < self._latest_movement_tick_id):
            raise ContractViolation("movement tick sample regressed")
        if len(self._observed_samples) >= self._max_samples:
            self._observed_samples.pop(min(self._observed_samples))
        self._observed_samples[sample.movement_tick_id] = sample
        self._latest_movement_tick_id = sample.movement_tick_id
        if sample.request_sequence_id is None:
            return None
        record = self._records.get(sample.request_sequence_id)
        if record is None or record.action.episode_id != sample.episode_id:
            raise ContractViolation("input sample has no submitted command")
        if sample.state == "disallowed":
            return self.reject(record.control_sequence, at_tick=sample.movement_tick_id)
        if sample.state in {"expired", "lease_exhausted"}:
            return self.expire(record.control_sequence, at_tick=sample.movement_tick_id)
        if sample.state not in {"leased", "neutral"}:
            return record
        ticks = tuple(sorted((*record.applied_ticks, sample.movement_tick_id)))
        samples_by_tick = {item.movement_tick_id: item for item in record.samples}
        samples_by_tick[sample.movement_tick_id] = sample
        samples = tuple(samples_by_tick[tick] for tick in ticks)
        if record.action.valid_for_ticks == 1:
            in_window = (
                len(ticks) == 1
                and record.requested_first_tick <= ticks[0]
                <= record.latest_allowed_first_tick
            )
            fully_applied = in_window
        else:
            expected_ticks = tuple(range(
                record.requested_first_tick, record.requested_last_tick + 1,
            ))
            in_window = all(tick in expected_ticks for tick in ticks)
            fully_applied = ticks == expected_ticks
        status = (InputApplicationStatus.APPLIED_OUTSIDE_WINDOW if not in_window
                  else InputApplicationStatus.APPLIED
                  if fully_applied
                  else InputApplicationStatus.PARTIALLY_APPLIED)
        updated = replace(
            record, status=status, applied_ticks=ticks, samples=samples,
            resolved_at_tick=max(ticks),
        )
        self._records[record.control_sequence] = updated
        self._supersede_older_records(
            record.control_sequence, sample.movement_tick_id, record.session,
        )
        return updated

    def _supersede_older_records(
        self,
        current_sequence: int,
        movement_tick_id: int,
        session: WorldSessionId,
    ) -> None:
        for sequence, candidate in tuple(self._records.items()):
            if (sequence >= current_sequence or candidate.session != session
                    or candidate.status not in {
                        InputApplicationStatus.IN_FLIGHT,
                        InputApplicationStatus.PARTIALLY_APPLIED,
                    }):
                continue
            self._records[sequence] = replace(
                candidate,
                status=InputApplicationStatus.SUPERSEDED,
                resolved_at_tick=movement_tick_id,
            )

    def observe_receipt(self, receipt: ClientBehaviorReceipt) -> tuple[InputApplicationRecord, ...]:
        if type(receipt) not in (ClientBehaviorReceiptV2, ClientBehaviorReceiptV3):
            raise ContractViolation("input ledger requires a formal behavior receipt")
        if (self._last_input_samples is not None
                and receipt.input_samples < self._last_input_samples):
            raise ContractViolation("input sample counter regressed")
        if (type(receipt) is ClientBehaviorReceiptV3
                and self._last_dropped_input_samples is not None
                and receipt.dropped_input_samples < self._last_dropped_input_samples):
            raise ContractViolation("dropped input sample counter regressed")
        changed: list[InputApplicationRecord] = []
        if type(receipt) is ClientBehaviorReceiptV3:
            for application in receipt.input_applications:
                record = self.observe_sample(application)
                if record is not None:
                    changed.append(record)
            if self._last_input_samples is not None:
                expected_ticks = set(range(
                    self._last_input_samples + 1, receipt.input_samples + 1,
                ))
                observed_ticks = {
                    application.movement_tick_id
                    for application in receipt.input_applications
                }
                if not expected_ticks.issubset(observed_ticks):
                    for record in tuple(self._records.values()):
                        if record.status in {
                            InputApplicationStatus.IN_FLIGHT,
                            InputApplicationStatus.PARTIALLY_APPLIED,
                        }:
                            changed.append(self.mark_ambiguous(
                                record.control_sequence,
                                at_tick=receipt.input_samples,
                            ))
        elif (self._last_input_samples is not None
              and receipt.input_samples > self._last_input_samples):
            for record in tuple(self._records.values()):
                if record.status in {
                    InputApplicationStatus.IN_FLIGHT,
                    InputApplicationStatus.PARTIALLY_APPLIED,
                }:
                    changed.append(self.mark_ambiguous(
                        record.control_sequence, at_tick=receipt.input_samples))
        if type(receipt) is ClientBehaviorReceiptV3:
            previous_dropped = self._last_dropped_input_samples or 0
            if receipt.dropped_input_samples > previous_dropped:
                for record in tuple(self._records.values()):
                    if record.status in {
                        InputApplicationStatus.IN_FLIGHT,
                        InputApplicationStatus.PARTIALLY_APPLIED,
                    }:
                        changed.append(self.mark_ambiguous(
                            record.control_sequence, at_tick=receipt.input_samples,
                        ))
            self._last_dropped_input_samples = receipt.dropped_input_samples
        self._last_input_samples = receipt.input_samples
        sequence = receipt.request_sequence_id
        if sequence is not None and sequence in self._records:
            record = self._records[sequence]
            if receipt.status in {"rejected", "cancelled"}:
                changed.append(self.reject(sequence, at_tick=receipt.input_samples))
            elif receipt.status == "timed_out":
                changed.append(self.expire(sequence, at_tick=receipt.input_samples))
        return tuple(changed)

    def expire(self, control_sequence: int, *, at_tick: int) -> InputApplicationRecord:
        return self._resolve(control_sequence, InputApplicationStatus.EXPIRED, at_tick)

    def reject(self, control_sequence: int, *, at_tick: int) -> InputApplicationRecord:
        return self._resolve(control_sequence, InputApplicationStatus.REJECTED, at_tick)

    def mark_ambiguous(self, control_sequence: int, *, at_tick: int) -> InputApplicationRecord:
        return self._resolve(control_sequence, InputApplicationStatus.AMBIGUOUS, at_tick)

    def snapshot(self) -> tuple[InputApplicationRecord, ...]:
        return tuple(self._records[key] for key in sorted(self._records))

    def _resolve(self, sequence: int, status: InputApplicationStatus,
                 tick: int) -> InputApplicationRecord:
        require_nonnegative_int(sequence, "control sequence")
        require_nonnegative_int(tick, "resolution tick")
        record = self._records.get(sequence)
        if record is None:
            raise ContractViolation("unknown control sequence")
        if record.status not in {
                InputApplicationStatus.IN_FLIGHT,
                InputApplicationStatus.PARTIALLY_APPLIED}:
            return record
        updated = replace(record, status=status, resolved_at_tick=tick)
        self._records[sequence] = updated
        return updated

    def _make_room(self) -> None:
        if len(self._records) < self._max_records:
            return
        evictable = next((key for key, record in self._records.items()
                          if record.status in _TERMINAL_INPUT_STATES), None)
        if evictable is None:
            raise ContractViolation("input ledger is full of unresolved records")
        self._records.pop(evictable)


class MotionTickPhase(StrEnum):
    BEFORE_INPUT_SAMPLE = "before_input_sample"
    AFTER_INPUT_BEFORE_MOVEMENT = "after_input_before_movement"
    AFTER_MOVEMENT = "after_movement"


class AnchorBuildStatus(StrEnum):
    READY = "ready"
    NEEDS_INPUT_CONFIRMATION = "needs_input_confirmation"
    DUPLICATE_OBSERVATION = "duplicate_observation"
    INVALID_INPUT = "invalid_input"


@dataclass(frozen=True, slots=True)
class StateAnchor:
    session: WorldSessionId
    observation_sequence_id: int
    movement_tick_id: int
    phase: MotionTickPhase
    confirmed_control_sequence: int | None
    confirmed_control_tick_range: tuple[int, int] | None
    ruleset_id: str
    state_schema: str
    input_projection_version: str
    physics_state: PhysicsState
    health_points: float | None = None
    absorption_points: float | None = None

    def __post_init__(self) -> None:
        for value, name in (
            (self.health_points, "anchor health points"),
            (self.absorption_points, "anchor absorption points"),
        ):
            if (value is not None
                    and (type(value) not in (int, float)
                         or not math.isfinite(float(value))
                         or float(value) < 0.0)):
                raise ContractViolation(f"{name} must be finite and nonnegative")


@dataclass(frozen=True, slots=True)
class AnchorBuildResult:
    status: AnchorBuildStatus
    anchor: StateAnchor | None = None
    unresolved_control_sequences: tuple[int, ...] = ()
    reasons: tuple[str, ...] = ()


class StateAnchorBuilder:
    def __init__(self, *, ruleset: PhysicsRuleset, input_projection_version: str) -> None:
        if type(ruleset) is not PhysicsRuleset:
            raise ContractViolation("state anchor requires a physics ruleset")
        require_identifier(input_projection_version, "input projection version")
        self._ruleset = ruleset
        self._projection = input_projection_version
        self._latest_accepted: dict[WorldSessionId, int] = {}

    def build(self, *, session: WorldSessionId, observation_sequence_id: int,
              movement_tick_id: int, phase: MotionTickPhase,
              physics_state: PhysicsState,
              ledger: InputApplicationLedger,
              health_points: float | None = None,
              absorption_points: float | None = None) -> AnchorBuildResult:
        if (type(session) is not WorldSessionId or type(physics_state) is not PhysicsState
                or type(ledger) is not InputApplicationLedger or type(phase) is not MotionTickPhase):
            raise ContractViolation("invalid state anchor inputs")
        require_nonnegative_int(observation_sequence_id, "observation sequence")
        require_nonnegative_int(movement_tick_id, "movement tick id")
        if observation_sequence_id <= self._latest_accepted.get(session, -1):
            return AnchorBuildResult(AnchorBuildStatus.DUPLICATE_OBSERVATION,
                                     reasons=("observation_did_not_advance",))
        if (physics_state.session != session
                or physics_state.ruleset_id != self._ruleset.ruleset_id
                or physics_state.state_schema != self._ruleset.state_schema):
            return AnchorBuildResult(AnchorBuildStatus.INVALID_INPUT,
                                     reasons=("state_identity_mismatch",))
        relevant = []
        for record in ledger.snapshot():
            if record.session != session or record.requested_first_tick > movement_tick_id:
                continue
            if record.status is InputApplicationStatus.AMBIGUOUS:
                relevant.append(record.control_sequence)
                continue
            if record.status in {
                    InputApplicationStatus.IN_FLIGHT,
                    InputApplicationStatus.PARTIALLY_APPLIED}:
                expected = set(range(
                    record.requested_first_tick,
                    min(record.requested_last_tick, movement_tick_id) + 1,
                ))
                if not expected.issubset(record.applied_ticks):
                    relevant.append(record.control_sequence)
        relevant = tuple(relevant)
        if relevant:
            return AnchorBuildResult(
                AnchorBuildStatus.NEEDS_INPUT_CONFIRMATION,
                unresolved_control_sequences=relevant,
            )
        confirmed = tuple(record for record in ledger.snapshot()
                          if record.session == session
                          and record.status in {
                              InputApplicationStatus.PARTIALLY_APPLIED,
                              InputApplicationStatus.APPLIED,
                              InputApplicationStatus.APPLIED_OUTSIDE_WINDOW,
                              InputApplicationStatus.SUPERSEDED,
                          }
                          and record.applied_ticks
                          and max(record.applied_ticks) <= movement_tick_id)
        latest = max(confirmed, key=lambda record: (
            max(record.applied_ticks), record.control_sequence,
        )) if confirmed else None
        state_at_tick = replace(physics_state, movement_tick_id=movement_tick_id)
        anchor = StateAnchor(
            session, observation_sequence_id, movement_tick_id, phase,
            latest.control_sequence if latest is not None else None,
            (min(latest.applied_ticks), max(latest.applied_ticks))
            if latest is not None else None,
            self._ruleset.ruleset_id,
            self._ruleset.state_schema, self._projection, state_at_tick,
            health_points, absorption_points,
        )
        self._latest_accepted[session] = observation_sequence_id
        return AnchorBuildResult(AnchorBuildStatus.READY, anchor=anchor)


class ProjectionStatus(StrEnum):
    READY = "ready"
    UNSUPPORTED = "unsupported"


@dataclass(frozen=True, slots=True)
class ProjectionResult:
    status: ProjectionStatus
    tick_input: TickInput | None = None
    reasons: tuple[str, ...] = ()


def project_movement_command(state: PhysicsState, command: MovementV1, *,
                             movement_yaw_radians: float | None = None) -> ProjectionResult:
    if type(state) is not PhysicsState or type(command) is not MovementV1:
        raise ContractViolation("input projection requires physics state and MovementV1")
    yaw = state.yaw_radians if movement_yaw_radians is None else movement_yaw_radians
    if type(yaw) not in (int, float) or not math.isfinite(float(yaw)):
        raise ContractViolation("movement yaw must be finite")
    if state.is_using_item:
        return ProjectionResult(
            ProjectionStatus.UNSUPPORTED,
            reasons=("item_slowdown_not_supported",),
        )
    # ClientBehaviorInput samples the discrete keys after applying the
    # vanilla crouch slowdown. The physics calculator consumes sampled axes.
    sampled_factor = .3 if command.sneak else 1.0
    return ProjectionResult(
        ProjectionStatus.READY,
        TickInput(float(command.forward) * sampled_factor,
                  float(command.strafe) * sampled_factor, command.jump,
                  command.sneak, command.sprint, float(yaw)),
    )


@dataclass(frozen=True, slots=True)
class PredictionValidity:
    anchor_movement_tick: int
    valid_through_tick: int
    dependencies: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        require_nonnegative_int(self.anchor_movement_tick, "anchor movement tick")
        require_nonnegative_int(self.valid_through_tick, "valid through tick")
        if self.valid_through_tick < self.anchor_movement_tick:
            raise ContractViolation("prediction validity ends before its anchor")

    def covers(self, movement_tick: int) -> bool:
        require_nonnegative_int(movement_tick, "movement tick")
        return self.anchor_movement_tick <= movement_tick <= self.valid_through_tick


@dataclass(frozen=True, slots=True)
class CandidateExecutionWindow:
    earliest_start_tick: int
    latest_start_tick: int

    def __post_init__(self) -> None:
        require_nonnegative_int(self.earliest_start_tick, "earliest start tick")
        require_nonnegative_int(self.latest_start_tick, "latest start tick")
        if self.latest_start_tick < self.earliest_start_tick:
            raise ContractViolation("candidate execution window is reversed")

    def allows_start(self, movement_tick: int) -> bool:
        require_nonnegative_int(movement_tick, "movement tick")
        return self.earliest_start_tick <= movement_tick <= self.latest_start_tick
